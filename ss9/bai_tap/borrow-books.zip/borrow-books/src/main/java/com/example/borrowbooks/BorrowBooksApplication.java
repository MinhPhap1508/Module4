package com.example.borrowbooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BorrowBooksApplication {

    public static void main(String[] args) {
        SpringApplication.run(BorrowBooksApplication.class, args);
    }

}
