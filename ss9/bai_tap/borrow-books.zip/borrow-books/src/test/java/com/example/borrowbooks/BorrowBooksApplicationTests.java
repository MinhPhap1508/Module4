package com.example.borrowbooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BorrowBooksApplicationTests {

    @Test
    void contextLoads() {
    }

}
